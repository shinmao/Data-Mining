import pandas as pd
import numpy as np
import sys

def check_male(ipt, gender):
    gender1 = pd.DataFrame({'antecedents': [], 'consequents': [], 'antecedent support': [], 'consequent support': [], 'support': [], 'confidence': [], 'lift': [], 'leverage': [], 'conviction': [], 'antecedent_len': [], 'consequents_len': []})
    if ipt[0] == 'M' and ipt[5] != '':
        male = 'Gender = M'
        product = ipt[5].split('/')
        gender = gender[gender['antecedents'].str.contains(male)]
        for i in range(len(product)):
            gender = gender[gender['antecedents'].str.contains(product[i])]
        gender1 = gender
    elif ipt[0] == 'M' and ipt[5] == '':
        # if there is only 'M' provided, we just provide the highest lift rule
        gender = gender[gender['lift'] > 5.3]
        gender1 = gender
    return gender1

def check_city(ipt, city_df):
    city_df1 = pd.DataFrame({'antecedents': [], 'consequents': [], 'antecedent support': [], 'consequent support': [], 'support': [], 'confidence': [], 'lift': [], 'leverage': [], 'conviction': [], 'antecedent_len': [], 'consequents_len': []})
    if ipt[1] == 'B' and ipt[5] != '':
        city = 'City = B'
        product = ipt[5].split('/')
        city_df = city_df[city_df['antecedents'].str.contains(city)]
        for i in range(len(product)):
            city_df = city_df[city_df['antecedents'].str.contains(product[i])]
        city_df1 = city_df
    elif ipt[1] == 'B' and ipt[5] == '':
        city_df = city_df[city_df['lift'] > 2.6]
        city_df1 = city_df
    return city_df1

def check_city_stay(ipt, city_stay_df):
    city_stay_df1 = pd.DataFrame({'antecedents': [], 'consequents': [], 'antecedent support': [], 'consequent support': [], 'support': [], 'confidence': [], 'lift': [], 'leverage': [], 'conviction': [], 'antecedent_len': [], 'consequents_len': []})
    if ipt[2] == '1' and ipt[5] != '':
        city_stay = 'Stay_In_Current_City_Years = 1'
        product = ipt[5].split('/')
        city_stay_df = city_stay_df[city_stay_df['antecedents'].str.contains(city_stay)]
        for i in range(len(product)):
            city_stay_df = city_stay_df[city_stay_df['antecedents'].str.contains(product[i])]
        city_stay_df1 = city_stay_df
    elif ipt[2] == '1' and ipt[5] == '':
        city_stay_df = city_stay_df[city_stay_df['lift'] > 2.08]
        city_stay_df1 = city_stay_df
    return city_stay_df1

def check_age(ipt, age_df):
    age_df1 = pd.DataFrame({'antecedents': [], 'consequents': [], 'antecedent support': [], 'consequent support': [], 'support': [], 'confidence': [], 'lift': [], 'leverage': [], 'conviction': [], 'antecedent_len': [], 'consequents_len': []})
    if ipt[3] == '26-35' and ipt[5] != '':
        age = 'Age = 26-35'
        product = ipt[5].split('/')
        age_df = age_df[age_df['antecedents'].str.contains(age)]
        for i in range(len(product)):
            age_df = age_df[age_df['antecedents'].str.contains(product[i])]
        age_df1 = age_df
    elif ipt[3] == '26-35' and ipt[5] == '':
        age_df = age_df[age_df['lift'] > 3.0]
        age_df1 = age_df
    return age_df1

def check_marital(ipt, marital_df):
    marital_df1 = pd.DataFrame({'antecedents': [], 'consequents': [], 'antecedent support': [], 'consequent support': [], 'support': [], 'confidence': [], 'lift': [], 'leverage': [], 'conviction': [], 'antecedent_len': [], 'consequents_len': []})
    if ipt[4] == '0' and ipt[5] != '':
        marital = 'Marital_Status = 0'
        product = ipt[5].split('/')
        marital_df = marital_df[marital_df['antecedents'].str.contains(marital)]
        for i in range(len(product)):
            marital_df = marital_df[marital_df['antecedents'].str.contains(product[i])]
        marital_df1 = marital_df
    elif ipt[4] == '0' and ipt[5] == '':
        marital_df = marital_df[marital_df['lift'] > 3.6]
        marital_df1 = marital_df
    return marital_df1

def check_product(ipt, product_df):
    product_df1 = pd.DataFrame({'antecedents': [], 'consequents': [], 'antecedent support': [], 'consequent support': [], 'support': [], 'confidence': [], 'lift': [], 'leverage': [], 'conviction': [], 'antecedent_len': [], 'consequents_len': []})
    if ipt[0] == '' and ipt[1] and '' and ipt[2] and '' and ipt[3] and '' and ipt[4] == '' and ipt[5] != '': 
        product = ipt[5].split('/')
        for i in range(len(product)):
            product_df = product_df[product_df['antecedents'].str.contains(product[i])]
        product_df1 = product_df
    return product_df1

def main():
    male = input("Male(M/F): ")
    city = input("City(A/B/C): ")
    city_stay = input("How long have stayed in city(0/1/2/3/4+): ")
    age = input("Age(0-17/18-25/26-35/36-45/46-50/51-55/55+): ")
    marital = input("Married or not(0/1): ")
    product = input("Cart(Split with / if several products): ")
    ipt = [male, city, city_stay, age, marital, product]
    gender = pd.read_csv('./output/gender/rules_freqitems_3_g.csv')
    city_df = pd.read_csv('./output/city/rules_freqitems_3_city.csv')
    city_stay_df = pd.read_csv('./output/city_stay/rules_freqitems_3_city_stay.csv')
    age_df = pd.read_csv('./output/age/rules_freqitems_3_age.csv')
    marital_df = pd.read_csv('./output/marital/rules_freqitems_3_marital.csv')
    product_df = pd.read_csv('./output/products/rules_freqitems_3_p.csv')
    recommend_list = []
    male_list = check_male(ipt, gender)
    city_list = check_city(ipt, city_df)
    citystay_list = check_city_stay(ipt, city_stay_df)
    age_list = check_age(ipt, age_df)
    marital_list = check_marital(ipt, marital_df)
    product_list = check_product(ipt, product_df)
    recommend_df = pd.concat([male_list, city_list, citystay_list, age_list, marital_list, product_list], sort=True)
    recommend_df = recommend_df.sort_values(by=['lift'], ascending=False)
    for r in recommend_df['consequents']:
        if r[9:] not in recommend_list:
            recommend_list.append(r[9:])
    print(recommend_list)

if __name__ == "__main__":
    main()