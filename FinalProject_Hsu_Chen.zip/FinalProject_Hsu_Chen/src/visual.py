import pandas as pd
import numpy as np
import random
import matplotlib.pyplot as plt
import networkx as nx

def draw_graph(rules):
    G1 = nx.DiGraph()
    color_map = []
    N = 400
    colors = np.random.rand(N)
    strs = []
    for i in range(8000):
        tmp = 'R'
        tmp += str(i)
        strs.append(tmp)

    rules = rules[rules['lift'] > 5.9]
    rules_to_show = len(rules)
    for i in range (rules_to_show):      
        G1.add_nodes_from(["R"+str(i)])
        for a in rules['antecedents']:        
            G1.add_nodes_from([a])
            G1.add_edge(a, "R"+str(i), color=colors[i] , weight = 2)
        for c in rules['consequents']:     
            G1.add_nodes_from([c])
            G1.add_edge("R"+str(i), c, color=colors[i],  weight=2)
 
    for node in G1:
       found_a_string = False
       for item in strs: 
           if node==item:
                found_a_string = True
       if found_a_string:
            color_map.append('yellow')
       else:
            color_map.append('green')       
   
    edges = G1.edges() 
    colors = [G1[u][v]['color'] for u,v in edges]
    weights = [G1[u][v]['weight'] for u,v in edges]
    pos = nx.spring_layout(G1, k=16, scale=1)
    nx.draw(G1, pos, edges=edges, node_color = color_map, edge_color=colors, width=weights, font_size=16, with_labels=False)            
    for p in pos:  # raise text positions
        pos[p][1] += 0.07
    nx.draw_networkx_labels(G1, pos)

def main():
    age_df = pd.read_csv('./age/rules_freqitems_3_age.csv')
    #draw_graph(age_df)
    #plt.savefig('./age/age.png')
    #plt.savefig('./age/lift_age.png')
    city_df = pd.read_csv('./city/rules_freqitems_3_city.csv')
    #draw_graph(city_df)
    #plt.savefig('./city/city.png')
    #plt.savefig('./city/lift_city.png')
    city_stay_df = pd.read_csv('./city_stay/rules_freqitems_3_city_stay.csv')
    #draw_graph(city_stay_df)
    #plt.savefig('./city_stay/city_stay.png')
    ## gender is tooooooo big!!
    gender = pd.read_csv('./gender/rules_freqitems_3_g.csv')
    #draw_graph(gender)
    #plt.savefig('./gender/gender.png')
    #plt.savefig('./gender/lift53_gender.png')
    marital = pd.read_csv('./marital/rules_freqitems_3_marital.csv')
    #draw_graph(marital)
    #plt.savefig('./marital/marital.png')
    #plt.savefig('./marital/lift36_marital.png')
    product = pd.read_csv('./products/rules_freqitems_3_p.csv')
    #draw_graph(product)
    #有有plt.savefig('./products/lift59.png')


if __name__ == "__main__":
    main()
    